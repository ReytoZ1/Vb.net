﻿Public Class Form11
    Private Sub Form11_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call Connection()
        Call Status()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Call DBview5()
    End Sub

    Private Sub bSearch_Click(sender As Object, e As EventArgs) Handles bSearch.Click
        Call Search2()
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            Call loadData()
        Else
            CheckBox1.CheckState = False
            DataGridView1.Rows.Clear()
            Return
        End If
    End Sub
End Class