﻿Public Class Form12
    Private Sub InserDateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InserDateToolStripMenuItem.Click
        RichTextBox1.Text = My.Computer.Clock.LocalTime & vbCrLf & RichTextBox1.Text
        RichTextBox1.Select(0, 0)  'remove selection
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        SaveFileDialog1.Filter = "Text files (*.txt)|*.txt"
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            'copy text to disk
            My.Computer.FileSystem.WriteAllText(
                SaveFileDialog1.FileName, RichTextBox1.Text, False)
        End If
    End Sub

    Private Sub bExit_Click(sender As Object, e As EventArgs) Handles bExit.Click
        Me.Close()
    End Sub
End Class