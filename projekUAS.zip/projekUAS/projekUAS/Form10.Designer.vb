﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form10
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form10))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.pOff = New System.Windows.Forms.PictureBox()
        Me.pOn = New System.Windows.Forms.PictureBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.t_Kelas = New System.Windows.Forms.TextBox()
        Me.dtp1 = New System.Windows.Forms.DateTimePicker()
        Me.l_Kelas = New System.Windows.Forms.Label()
        Me.l_NIM = New System.Windows.Forms.Label()
        Me.t_Nama = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.l_Nama = New System.Windows.Forms.Label()
        Me.t_NIM = New System.Windows.Forms.TextBox()
        Me.tbAssign = New System.Windows.Forms.TextBox()
        Me.lblHuruf = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        CType(Me.pOff, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pOn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.RichTextBox1)
        Me.Panel1.Controls.Add(Me.pOff)
        Me.Panel1.Controls.Add(Me.pOn)
        Me.Panel1.Controls.Add(Me.DataGridView1)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.ForeColor = System.Drawing.Color.Black
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1011, 515)
        Me.Panel1.TabIndex = 2
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Enabled = False
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 181)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(489, 290)
        Me.RichTextBox1.TabIndex = 96
        Me.RichTextBox1.Text = ""
        '
        'pOff
        '
        Me.pOff.Image = CType(resources.GetObject("pOff.Image"), System.Drawing.Image)
        Me.pOff.Location = New System.Drawing.Point(951, 12)
        Me.pOff.Name = "pOff"
        Me.pOff.Size = New System.Drawing.Size(25, 25)
        Me.pOff.TabIndex = 81
        Me.pOff.TabStop = False
        Me.pOff.Visible = False
        '
        'pOn
        '
        Me.pOn.Image = CType(resources.GetObject("pOn.Image"), System.Drawing.Image)
        Me.pOn.Location = New System.Drawing.Point(951, 14)
        Me.pOn.Name = "pOn"
        Me.pOn.Size = New System.Drawing.Size(25, 27)
        Me.pOn.TabIndex = 80
        Me.pOn.TabStop = False
        Me.pOn.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column3, Me.Column4, Me.Column5, Me.Column6, Me.Column7})
        Me.DataGridView1.Location = New System.Drawing.Point(507, 181)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(469, 290)
        Me.DataGridView1.TabIndex = 73
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column1.HeaderText = "Nama"
        Me.Column1.MinimumWidth = 6
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 64
        '
        'Column3
        '
        Me.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column3.HeaderText = "NIM"
        Me.Column3.MinimumWidth = 6
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 55
        '
        'Column4
        '
        Me.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column4.HeaderText = "Kelas"
        Me.Column4.MinimumWidth = 6
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 59
        '
        'Column5
        '
        Me.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column5.HeaderText = "Judul Tugas"
        Me.Column5.MinimumWidth = 6
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Width = 94
        '
        'Column6
        '
        Me.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column6.HeaderText = "Isi Tugas"
        Me.Column6.MinimumWidth = 6
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        Me.Column6.Width = 77
        '
        'Column7
        '
        Me.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column7.HeaderText = "Tanggal"
        Me.Column7.MinimumWidth = 6
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Width = 73
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(889, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 20)
        Me.Label3.TabIndex = 72
        Me.Label3.Text = "Status :"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.t_Kelas)
        Me.GroupBox1.Controls.Add(Me.dtp1)
        Me.GroupBox1.Controls.Add(Me.l_Kelas)
        Me.GroupBox1.Controls.Add(Me.l_NIM)
        Me.GroupBox1.Controls.Add(Me.t_Nama)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.l_Nama)
        Me.GroupBox1.Controls.Add(Me.t_NIM)
        Me.GroupBox1.Controls.Add(Me.tbAssign)
        Me.GroupBox1.Controls.Add(Me.lblHuruf)
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(12, 58)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(964, 93)
        Me.GroupBox1.TabIndex = 95
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Read Only"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(21, 64)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(178, 5)
        Me.Label7.TabIndex = 98
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(573, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(178, 5)
        Me.Label6.TabIndex = 97
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(205, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(178, 5)
        Me.Label2.TabIndex = 96
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(389, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(178, 5)
        Me.Label1.TabIndex = 95
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(757, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(178, 5)
        Me.Label5.TabIndex = 94
        '
        't_Kelas
        '
        Me.t_Kelas.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.t_Kelas.Enabled = False
        Me.t_Kelas.Location = New System.Drawing.Point(757, 45)
        Me.t_Kelas.Name = "t_Kelas"
        Me.t_Kelas.Size = New System.Drawing.Size(176, 16)
        Me.t_Kelas.TabIndex = 91
        '
        'dtp1
        '
        Me.dtp1.CalendarMonthBackground = System.Drawing.Color.White
        Me.dtp1.CalendarTrailingForeColor = System.Drawing.Color.White
        Me.dtp1.CustomFormat = "dd-MM-yyyy"
        Me.dtp1.Enabled = False
        Me.dtp1.Location = New System.Drawing.Point(205, 40)
        Me.dtp1.Name = "dtp1"
        Me.dtp1.Size = New System.Drawing.Size(178, 23)
        Me.dtp1.TabIndex = 93
        '
        'l_Kelas
        '
        Me.l_Kelas.AutoSize = True
        Me.l_Kelas.ForeColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.l_Kelas.Location = New System.Drawing.Point(757, 31)
        Me.l_Kelas.Name = "l_Kelas"
        Me.l_Kelas.Size = New System.Drawing.Size(34, 15)
        Me.l_Kelas.TabIndex = 90
        Me.l_Kelas.Text = "Kelas"
        '
        'l_NIM
        '
        Me.l_NIM.AutoSize = True
        Me.l_NIM.ForeColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.l_NIM.Location = New System.Drawing.Point(573, 31)
        Me.l_NIM.Name = "l_NIM"
        Me.l_NIM.Size = New System.Drawing.Size(30, 15)
        Me.l_NIM.TabIndex = 88
        Me.l_NIM.Text = "NIM"
        '
        't_Nama
        '
        Me.t_Nama.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.t_Nama.Enabled = False
        Me.t_Nama.Location = New System.Drawing.Point(389, 45)
        Me.t_Nama.Name = "t_Nama"
        Me.t_Nama.Size = New System.Drawing.Size(178, 16)
        Me.t_Nama.TabIndex = 87
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(205, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 15)
        Me.Label4.TabIndex = 92
        Me.Label4.Text = "Tanggal"
        '
        'l_Nama
        '
        Me.l_Nama.AutoSize = True
        Me.l_Nama.ForeColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.l_Nama.Location = New System.Drawing.Point(389, 27)
        Me.l_Nama.Name = "l_Nama"
        Me.l_Nama.Size = New System.Drawing.Size(39, 15)
        Me.l_Nama.TabIndex = 86
        Me.l_Nama.Text = "Nama"
        '
        't_NIM
        '
        Me.t_NIM.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.t_NIM.Enabled = False
        Me.t_NIM.Location = New System.Drawing.Point(573, 46)
        Me.t_NIM.Name = "t_NIM"
        Me.t_NIM.Size = New System.Drawing.Size(178, 16)
        Me.t_NIM.TabIndex = 89
        '
        'tbAssign
        '
        Me.tbAssign.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tbAssign.Enabled = False
        Me.tbAssign.Location = New System.Drawing.Point(21, 45)
        Me.tbAssign.Name = "tbAssign"
        Me.tbAssign.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tbAssign.Size = New System.Drawing.Size(178, 16)
        Me.tbAssign.TabIndex = 63
        '
        'lblHuruf
        '
        Me.lblHuruf.AutoSize = True
        Me.lblHuruf.ForeColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.lblHuruf.Location = New System.Drawing.Point(21, 31)
        Me.lblHuruf.Name = "lblHuruf"
        Me.lblHuruf.Size = New System.Drawing.Size(70, 15)
        Me.lblHuruf.TabIndex = 60
        Me.lblHuruf.Text = "Assignment"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(27, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(252, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(33, 163)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 15)
        Me.Label8.TabIndex = 99
        Me.Label8.Text = "Text "
        '
        'Form10
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1011, 515)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form10"
        Me.Text = "Form10"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.pOff, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pOn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents t_Kelas As TextBox
    Friend WithEvents l_Kelas As Label
    Friend WithEvents t_Nama As TextBox
    Friend WithEvents l_Nama As Label
    Friend WithEvents pOff As PictureBox
    Friend WithEvents pOn As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents tbAssign As TextBox
    Friend WithEvents lblHuruf As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents dtp1 As DateTimePicker
    Friend WithEvents l_NIM As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents t_NIM As TextBox
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column7 As DataGridViewTextBoxColumn
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
End Class
