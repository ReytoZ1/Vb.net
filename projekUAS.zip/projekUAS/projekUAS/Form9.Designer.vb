﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form9
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form9))
        Me.Label3 = New System.Windows.Forms.Label()
        Me.pOn = New System.Windows.Forms.PictureBox()
        Me.pOff = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.rbTidak = New System.Windows.Forms.RadioButton()
        Me.lblYakin = New System.Windows.Forms.Label()
        Me.rbYa = New System.Windows.Forms.RadioButton()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.bSubmit = New System.Windows.Forms.Button()
        Me.cb1 = New System.Windows.Forms.ComboBox()
        Me.t_Kelas = New System.Windows.Forms.TextBox()
        Me.t_NIM = New System.Windows.Forms.TextBox()
        Me.t_Nama = New System.Windows.Forms.TextBox()
        Me.lblKehadiran = New System.Windows.Forms.Label()
        Me.lblTanggal = New System.Windows.Forms.Label()
        Me.lblKelas = New System.Windows.Forms.Label()
        Me.lblNim = New System.Windows.Forms.Label()
        Me.lblNama = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.bSearch = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.tbSearch = New System.Windows.Forms.TextBox()
        Me.lblSearch = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        CType(Me.pOn, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pOff, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(867, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 20)
        Me.Label3.TabIndex = 82
        Me.Label3.Text = "Status :"
        '
        'pOn
        '
        Me.pOn.Image = CType(resources.GetObject("pOn.Image"), System.Drawing.Image)
        Me.pOn.Location = New System.Drawing.Point(929, 13)
        Me.pOn.Name = "pOn"
        Me.pOn.Size = New System.Drawing.Size(25, 27)
        Me.pOn.TabIndex = 83
        Me.pOn.TabStop = False
        Me.pOn.Visible = False
        '
        'pOff
        '
        Me.pOff.Image = CType(resources.GetObject("pOff.Image"), System.Drawing.Image)
        Me.pOff.Location = New System.Drawing.Point(929, 12)
        Me.pOff.Name = "pOff"
        Me.pOff.Size = New System.Drawing.Size(25, 25)
        Me.pOff.TabIndex = 84
        Me.pOff.TabStop = False
        Me.pOff.Visible = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.DateTimePicker1)
        Me.Panel2.Controls.Add(Me.PictureBox1)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.rbTidak)
        Me.Panel2.Controls.Add(Me.lblYakin)
        Me.Panel2.Controls.Add(Me.rbYa)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.CheckBox1)
        Me.Panel2.Controls.Add(Me.bSubmit)
        Me.Panel2.Controls.Add(Me.cb1)
        Me.Panel2.Controls.Add(Me.t_Kelas)
        Me.Panel2.Controls.Add(Me.t_NIM)
        Me.Panel2.Controls.Add(Me.t_Nama)
        Me.Panel2.Controls.Add(Me.lblKehadiran)
        Me.Panel2.Controls.Add(Me.lblTanggal)
        Me.Panel2.Controls.Add(Me.lblKelas)
        Me.Panel2.Controls.Add(Me.lblNim)
        Me.Panel2.Controls.Add(Me.lblNama)
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Location = New System.Drawing.Point(33, 48)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(911, 434)
        Me.Panel2.TabIndex = 85
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(79, 6)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(94, 84)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 40
        Me.PictureBox1.TabStop = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Stencil", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(179, 32)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(127, 22)
        Me.Label10.TabIndex = 39
        Me.Label10.Text = "Attendance"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(139, 402)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(146, 5)
        Me.Label9.TabIndex = 38
        '
        'rbTidak
        '
        Me.rbTidak.AutoSize = True
        Me.rbTidak.ForeColor = System.Drawing.Color.Black
        Me.rbTidak.Location = New System.Drawing.Point(221, 380)
        Me.rbTidak.Name = "rbTidak"
        Me.rbTidak.Size = New System.Drawing.Size(53, 19)
        Me.rbTidak.TabIndex = 37
        Me.rbTidak.TabStop = True
        Me.rbTidak.Text = "Tidak"
        Me.rbTidak.UseVisualStyleBackColor = True
        '
        'lblYakin
        '
        Me.lblYakin.AutoSize = True
        Me.lblYakin.ForeColor = System.Drawing.Color.Black
        Me.lblYakin.Location = New System.Drawing.Point(179, 362)
        Me.lblYakin.Name = "lblYakin"
        Me.lblYakin.Size = New System.Drawing.Size(71, 15)
        Me.lblYakin.TabIndex = 36
        Me.lblYakin.Text = "Anda Yakin?"
        '
        'rbYa
        '
        Me.rbYa.AutoSize = True
        Me.rbYa.ForeColor = System.Drawing.Color.Black
        Me.rbYa.Location = New System.Drawing.Point(162, 380)
        Me.rbYa.Name = "rbYa"
        Me.rbYa.Size = New System.Drawing.Size(37, 19)
        Me.rbYa.TabIndex = 35
        Me.rbYa.TabStop = True
        Me.rbYa.Text = "Ya"
        Me.rbYa.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(237, 297)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(161, 5)
        Me.Label7.TabIndex = 34
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(237, 138)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(161, 5)
        Me.Label6.TabIndex = 33
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(237, 205)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(161, 5)
        Me.Label5.TabIndex = 32
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(25, 196)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(161, 5)
        Me.Label2.TabIndex = 31
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(25, 131)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(161, 5)
        Me.Label1.TabIndex = 30
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(25, 265)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(161, 5)
        Me.Label4.TabIndex = 29
        '
        'CheckBox1
        '
        Me.CheckBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.CheckBox1.Location = New System.Drawing.Point(237, 213)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(175, 81)
        Me.CheckBox1.TabIndex = 12
        Me.CheckBox1.Text = "Dengan ini saya menyatakan demi Tuhan  bahwa saya mengisi absen dengan sejujurnya" &
    ""
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'bSubmit
        '
        Me.bSubmit.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.bSubmit.FlatAppearance.BorderSize = 0
        Me.bSubmit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.bSubmit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bSubmit.ForeColor = System.Drawing.Color.White
        Me.bSubmit.Location = New System.Drawing.Point(139, 318)
        Me.bSubmit.Name = "bSubmit"
        Me.bSubmit.Size = New System.Drawing.Size(146, 23)
        Me.bSubmit.TabIndex = 11
        Me.bSubmit.Text = "Submit"
        Me.bSubmit.UseVisualStyleBackColor = False
        '
        'cb1
        '
        Me.cb1.FormattingEnabled = True
        Me.cb1.Items.AddRange(New Object() {"Hadir", "Terlambat"})
        Me.cb1.Location = New System.Drawing.Point(237, 112)
        Me.cb1.Name = "cb1"
        Me.cb1.Size = New System.Drawing.Size(161, 23)
        Me.cb1.TabIndex = 9
        '
        't_Kelas
        '
        Me.t_Kelas.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.t_Kelas.Location = New System.Drawing.Point(25, 246)
        Me.t_Kelas.Name = "t_Kelas"
        Me.t_Kelas.Size = New System.Drawing.Size(161, 16)
        Me.t_Kelas.TabIndex = 8
        Me.t_Kelas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        't_NIM
        '
        Me.t_NIM.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.t_NIM.Location = New System.Drawing.Point(25, 177)
        Me.t_NIM.Name = "t_NIM"
        Me.t_NIM.Size = New System.Drawing.Size(161, 16)
        Me.t_NIM.TabIndex = 7
        Me.t_NIM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        't_Nama
        '
        Me.t_Nama.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.t_Nama.Location = New System.Drawing.Point(25, 112)
        Me.t_Nama.Name = "t_Nama"
        Me.t_Nama.Size = New System.Drawing.Size(161, 16)
        Me.t_Nama.TabIndex = 6
        Me.t_Nama.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblKehadiran
        '
        Me.lblKehadiran.AutoSize = True
        Me.lblKehadiran.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.lblKehadiran.Location = New System.Drawing.Point(237, 94)
        Me.lblKehadiran.Name = "lblKehadiran"
        Me.lblKehadiran.Size = New System.Drawing.Size(60, 15)
        Me.lblKehadiran.TabIndex = 5
        Me.lblKehadiran.Text = "Kehadiran"
        '
        'lblTanggal
        '
        Me.lblTanggal.AutoSize = True
        Me.lblTanggal.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.lblTanggal.Location = New System.Drawing.Point(237, 159)
        Me.lblTanggal.Name = "lblTanggal"
        Me.lblTanggal.Size = New System.Drawing.Size(48, 15)
        Me.lblTanggal.TabIndex = 4
        Me.lblTanggal.Text = "Tanggal"
        '
        'lblKelas
        '
        Me.lblKelas.AutoSize = True
        Me.lblKelas.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.lblKelas.Location = New System.Drawing.Point(25, 228)
        Me.lblKelas.Name = "lblKelas"
        Me.lblKelas.Size = New System.Drawing.Size(34, 15)
        Me.lblKelas.TabIndex = 3
        Me.lblKelas.Text = "Kelas"
        '
        'lblNim
        '
        Me.lblNim.AutoSize = True
        Me.lblNim.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.lblNim.Location = New System.Drawing.Point(25, 159)
        Me.lblNim.Name = "lblNim"
        Me.lblNim.Size = New System.Drawing.Size(30, 15)
        Me.lblNim.TabIndex = 2
        Me.lblNim.Text = "NIM"
        '
        'lblNama
        '
        Me.lblNama.AutoSize = True
        Me.lblNama.ForeColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.lblNama.Location = New System.Drawing.Point(25, 98)
        Me.lblNama.Name = "lblNama"
        Me.lblNama.Size = New System.Drawing.Size(39, 15)
        Me.lblNama.TabIndex = 1
        Me.lblNama.Text = "Nama"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(44, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(71, Byte), Integer))
        Me.Panel3.Controls.Add(Me.bSearch)
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.tbSearch)
        Me.Panel3.Controls.Add(Me.lblSearch)
        Me.Panel3.Controls.Add(Me.DataGridView1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(470, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(441, 434)
        Me.Panel3.TabIndex = 0
        '
        'bSearch
        '
        Me.bSearch.BackColor = System.Drawing.Color.FromArgb(CType(CType(24, Byte), Integer), CType(CType(44, Byte), Integer), CType(CType(97, Byte), Integer))
        Me.bSearch.FlatAppearance.BorderSize = 0
        Me.bSearch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White
        Me.bSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.bSearch.ForeColor = System.Drawing.Color.White
        Me.bSearch.Location = New System.Drawing.Point(293, 33)
        Me.bSearch.Name = "bSearch"
        Me.bSearch.Size = New System.Drawing.Size(113, 23)
        Me.bSearch.TabIndex = 36
        Me.bSearch.Text = "Search"
        Me.bSearch.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(48, 45)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(226, 5)
        Me.Label8.TabIndex = 35
        '
        'tbSearch
        '
        Me.tbSearch.BackColor = System.Drawing.Color.White
        Me.tbSearch.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tbSearch.Location = New System.Drawing.Point(48, 24)
        Me.tbSearch.Name = "tbSearch"
        Me.tbSearch.Size = New System.Drawing.Size(226, 16)
        Me.tbSearch.TabIndex = 3
        Me.tbSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblSearch
        '
        Me.lblSearch.AutoSize = True
        Me.lblSearch.ForeColor = System.Drawing.Color.White
        Me.lblSearch.Location = New System.Drawing.Point(48, 6)
        Me.lblSearch.Name = "lblSearch"
        Me.lblSearch.Size = New System.Drawing.Size(42, 15)
        Me.lblSearch.TabIndex = 2
        Me.lblSearch.Text = "Search"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        Me.DataGridView1.GridColor = System.Drawing.Color.Black
        Me.DataGridView1.Location = New System.Drawing.Point(12, 62)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowTemplate.Height = 25
        Me.DataGridView1.Size = New System.Drawing.Size(417, 358)
        Me.DataGridView1.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column1.HeaderText = "Nama"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 64
        '
        'Column2
        '
        Me.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column2.HeaderText = "NIM"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 55
        '
        'Column3
        '
        Me.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column3.HeaderText = "Kelas"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 59
        '
        'Column4
        '
        Me.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column4.HeaderText = "Kehadiran"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Width = 85
        '
        'Column5
        '
        Me.Column5.HeaderText = "Tanggal"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.pOff)
        Me.Panel1.Controls.Add(Me.pOn)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(984, 513)
        Me.Panel1.TabIndex = 0
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(237, 178)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(161, 23)
        Me.DateTimePicker1.TabIndex = 41
        '
        'Form9
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 513)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form9"
        Me.Text = "Form9"
        CType(Me.pOn, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pOff, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label3 As Label
    Friend WithEvents pOn As PictureBox
    Friend WithEvents pOff As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents bSubmit As Button
    Friend WithEvents cb1 As ComboBox
    Friend WithEvents t_Kelas As TextBox
    Friend WithEvents t_NIM As TextBox
    Friend WithEvents t_Nama As TextBox
    Friend WithEvents lblKehadiran As Label
    Friend WithEvents lblTanggal As Label
    Friend WithEvents lblKelas As Label
    Friend WithEvents lblNim As Label
    Friend WithEvents lblNama As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents tbSearch As TextBox
    Friend WithEvents lblSearch As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label9 As Label
    Friend WithEvents rbTidak As RadioButton
    Friend WithEvents lblYakin As Label
    Friend WithEvents rbYa As RadioButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label10 As Label
    Friend WithEvents bSearch As Button
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
