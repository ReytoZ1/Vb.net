﻿Public Class Form10
    Private Sub Form10_Load(sender As Object, e As EventArgs) Handles Me.Load
        Call Connection()
        Call Status()
        Call loadData()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Call DBview6()
        loadData()
    End Sub


End Class